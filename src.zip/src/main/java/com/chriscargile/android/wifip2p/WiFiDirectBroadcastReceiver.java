package com.chriscargile.android.wifip2p;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.util.Log;
import android.widget.TextView;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author Chris for CSCI690
 * this class uses the arguments of constructor to notify the activity
 * when intents are received and to advertise the peers discovered (if so)
 * when the WIFI state is set to enabled on the device.
 *
 * Code is attributable to developers.android.com topic:wifip2p, mostly
 * and is demo'd working on two ZTE Zinger Android handhelds c.Mar'15
 *
 * A BroadcastReceiver that notifies of important Wi-Fi p2p events.
 */
public class WiFiDirectBroadcastReceiver extends BroadcastReceiver implements WifiP2pManager.PeerListListener,WifiP2pManager.ConnectionInfoListener {

    private WifiP2pManager mManager;
    private WifiP2pManager.Channel mChannel;
    private MyWiFiActivity mActivity;
    WifiP2pManager.PeerListListener myPeerListListener;
    WifiP2pManager.ConnectionInfoListener myConnectionInfoListener;
    WifiP2pDeviceList peerList;
    public ArrayList<String> peersFound;
    public WifiP2pDevice firstDeviceFound;

    public WiFiDirectBroadcastReceiver(WifiP2pManager manager, WifiP2pManager.Channel channel,
                                       MyWiFiActivity activity) {
        super();
        this.mManager = manager;
        this.mChannel = channel;
        this.mActivity = activity;
        peerList = new WifiP2pDeviceList();
        myPeerListListener = this;
        discoverPeers();
    }

    public void discoverPeers(){
        mManager.discoverPeers(mChannel, new WifiP2pManager.ActionListener() {
            @Override
            public void onSuccess() {
                Log.w("discovering","peer discovery a success");
            }

            @Override
            public void onFailure(int reasonCode) {
                Log.w("discovering","peer discovery a fail");
            }
        });
    }


    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
            // Check to see if Wi-Fi is enabled and notify appropriate activity
            int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);

            if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                // Wifi P2P is enabled
                Log.w("receiver", "p2p state enabled");
            } else {
                // Wi-Fi P2P is not enabled
                Log.w("receiver", "p2p state not enabled");
            }

        } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {
            // Call WifiP2pManager.requestPeers() to get a list of current peers
            if (mManager != null) {
                mManager.requestPeers(mChannel, this);
                Log.w("receiver", "onPeersAvailable called and peerlist=");
            }

        } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {
            // Respond to new connection or disconnections
            mManager.requestConnectionInfo(mChannel,this);
        } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {
            // Respond to this device's wifi state changing
            Log.w("receiver", "this device's wifi p2p changed action (wifi state changed)");
        }
    }

    @Override
    public void onPeersAvailable(WifiP2pDeviceList peerList) {
        if(peerList!=null)
            ;//Log.w("receiver", "peerlist!=null");
        else
            Log.w("receiver", "peerlist=null");
        peersFound = new ArrayList<String>();
        WifiP2pDevice device = null;
        Collection<WifiP2pDevice> coll = peerList.getDeviceList();
        if(coll!=null){
            Iterator it = coll.iterator();
            while(it.hasNext()){
                device = (WifiP2pDevice) it.next();
                //Log.w("devcs fnd@addresses",device.deviceName+": "+device.deviceAddress.toString());
                peersFound.add(device.deviceAddress);
            }
        }
        else
            Log.w("devcs fnd@addresses","get device list=null");
        if(device!=null){
            final WifiP2pConfig config = new WifiP2pConfig();
            config.deviceAddress = device.deviceAddress;
            firstDeviceFound = device;
            mManager.connect(mChannel, config, new WifiP2pManager.ActionListener() {

                @Override
                public void onSuccess() {
                    //success logic
                    Log.w("connect to:",config.deviceAddress+"=success");
                    //mManager.requestConnectionInfo(mChannel,);
                }

                @Override
                public void onFailure(int reason) {
                    //failure logic
                }
            });

        }
        mManager.requestPeers(mChannel, this);
    }

    @Override
    public void onConnectionInfoAvailable(WifiP2pInfo info) {
        String packetInfo = info.isGroupOwner +" " +String.valueOf(info.groupFormed);
        Log.w(this.toString(),packetInfo);
    }
}
