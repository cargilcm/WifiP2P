package com.chriscargile.android.wifip2p;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MyWiFiActivity extends Activity {

    WifiP2pManager mManager;
    WifiP2pManager.Channel mChannel;
    WiFiDirectBroadcastReceiver mReceiver;
    IntentFilter mIntentFilter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_connect);
        mManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        mChannel = mManager.initialize(this, getMainLooper(), null);
        mReceiver = new WiFiDirectBroadcastReceiver(mManager, mChannel, this);

        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);


    }

    /* register the broadcast receiver with the intent values to be matched */
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mReceiver, mIntentFilter);
    }
    /* unregister the broadcast receiver */
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mReceiver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_wifi_connect, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //show_peers vs. settings
        if (id == R.id.action_settings) {
            mReceiver.onPeersAvailable(mReceiver.peerList);

            ListView listView= (ListView)findViewById( R.id.list);
            ArrayList<String> defaultList = mReceiver.peersFound;
            ArrayAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mReceiver.peersFound);
            listView.setAdapter(adapter);

            String size = String.valueOf(mReceiver.peersFound.size());
            Log.w("peersFound.size=", size);
            TextView textView = (TextView)findViewById(R.id.tv_hw);
            if(mReceiver.firstDeviceFound!=null){
                mReceiver.peersFound.add(mReceiver.firstDeviceFound.deviceName);
                adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mReceiver.peersFound);
                listView.setAdapter(adapter);
                String isSDC = "isSDC:"+String.valueOf(mReceiver.firstDeviceFound.isServiceDiscoveryCapable());
                Toast.makeText(this,isSDC,Toast.LENGTH_SHORT).show();
            }
            else
                textView.setText("firstDeviceFound=null");

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
